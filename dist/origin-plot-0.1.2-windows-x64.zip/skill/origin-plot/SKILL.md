---
name: origin-plot
description: 使用本机 Windows Origin 或 OriginPro，从 CSV、TSV、XLSX 创建可编辑的科研图和 OPJU，按论文期刊规范导出，或打开已有工程、连接当前窗口，精确修改曲线、坐标轴、图层与图例。也可离线检索和比较 Origin 原生图模板。
---

# Origin 科研绘图

以用户的原始数据、图中对象和目标输出为依据。工具由本地 `origin-plot` MCP 提供；安装器另注册 `origin-plot-current`，供用户指定修改当前 Origin 窗口时使用。客户端可为工具名添加不同前缀。

## 选择工作路径

- **寻找模板。** 用 `scripts/catalog.py search 关键词` 或 `list --source official --json` 查看官方版本、输入角色、适用入口及实机验证状态。模板依赖示例工程或专用脚本时，先核对目录要求。
- **新画图。** 在独立会话调用 `origin_plot_doctor`。读取所选配方的 `assets/recipes/<id>/recipe.json` 和例数据，核对用户数据的列、单位及分组后调用渲染工具。输入为既有汇总值、区间或系数时，沿用用户给出的定义。选择直方图、小提琴或箱线图时先确认有原始观测。
- **用模板换数据。** 自带配方用 `origin_plot_render` 传 `template_path`。通用 OTPU 用 `origin_plot_inspect(template_path=...)` 了解模板图层，再用 `origin_plot_render_template` 逐曲线映射实际列名。统计分组或面板结构变化时选同类配方并用原生模板重新生成工程。
- **修改已有图。** 先读取工程、图页、图层、曲线和数据列，按实际标识定位对象。用 `origin_plot_edit` 的 `bindings` 在独立 OPJU 副本替换所选源数据，也可传 `changes` 同时修改样式。只有明确要求修改当前窗口的样式时才用 current 服务和检查令牌。会话、工程或对象不符时停止写入。
- **按目标期刊交付。** 在本 Skill 的 `scripts` 目录运行 `python -m journals prompt <journal>`，将输出作为本次绘图的期刊指令。根据提示核对稿件阶段、栏宽、多面板和素材类型，最后用实测成图检查。详细入口见 `references/workflow.md`。

## 完成交付

给用户可打开的 OPJU、PNG 预览和约定格式的最终图件。确认路径存在、图形可见，检查在最终尺寸下的轴标签、单位、图例与面板号。需要保证可持续编辑时，重开副本核对数据绑定和指定图形属性。只有实际完成的步骤才列为通过。缺少 Origin、可用许可证或 COM 时，仍可以检索本地图集、核对输入与生成配方，原生文件的状态保持待实机生成。
